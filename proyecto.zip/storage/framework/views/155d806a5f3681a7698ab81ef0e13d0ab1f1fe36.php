

<?php $__env->startSection('dashboard_content'); ?>
    <div class="cont_integrante" style="display: flex; flex-direction:row; width: 100%; height: 100%">
        <section style="width: 50%; border-right: solid 1px #000;padding:2%;">
            <h1>Añadir Integrante</h1>
            <form action="<?php echo e(route('comite.integrantes.store')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <input type="hidden" value="<?php echo e($idComite); ?>" name="idComite">
                <div class="mb-3">
                    <label for="docente" class="form-label">Seleccionar Docente</label>
                    <select class="form-control" id="docente" name="docente" required>
                        <option value="" selected disabled>Seleccionar integrante</option>
                        <?php $__currentLoopData = $docentes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $docente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($docente->id); ?>">
                                <?php echo e($docente->numeroDocumento . ' - ' . $docente->nombre . ' ' . $docente->apellido); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <button class="btn btn-success">Seleccionar Integrante</button>
            </form>
        </section>
        <section style="width: calc(50% - 1px); padding:2%;">
            <table class="table table-hover shadow-lg mt-4" style="width:100%" id='table-js'>
                <thead>
                    <tr>
                        <th scope="col">Documento</th>
                        <th scope="col">Nombre</th>
                        <th scope="col"></th>
                    </tr>
                </thead>

                <tbody>
                    <?php $__currentLoopData = $integrantes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $integrante): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($integrante->usuario); ?></td>
                            <td><?php echo e($integrante->nombre ." ". $integrante->apellido); ?></td>
                            <td><button class="btn btn-outline-danger"><i class="bi bi-trash-fill"></i></button></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </section>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\GestionProyectosGrado\resources\views/Layouts/comites/create-integrante.blade.php ENDPATH**/ ?>