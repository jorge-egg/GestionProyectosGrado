
<?php $__env->startSection('estilos_adicionales'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/coloresBtnCampos.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/contenedorButtons.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('dashboard_content'); ?>
    <div class="grid">
        <div class="modal fade" tabindex="-1" id="confirmacionIntegrante">
            <?php $__env->startComponent('components.Modales.confirmacionIntegrante'); ?>
            <?php echo $__env->renderComponent(); ?>
        </div>

        <div class="modal fade" tabindex="-1" id="integrantesModal">
            <?php $__env->startComponent('components.Modales.integrantesModal'); ?>
            <?php echo $__env->renderComponent(); ?>
        </div>
        <div class="modal fade" tabindex="-1" id="buscarIntegranteModal">
            <?php $__env->startComponent('components.Modales.buscarIntegranteModal'); ?>

            <?php echo $__env->renderComponent(); ?>
        </div>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('proyecto.crear')): ?>
            <?php if($estado): ?>
                <button type="submit" class="btn btn-outline-primary btnGrandeRectangular btn-deshabilitado"
                    data-bs-toggle="modal" data-bs-target="#confirmacionIntegrante" disabled>
                    <h3><b>Crear un proyecto</b></h3><br>
                    <p><small>Crea un proyecto de grado indiviual o en pareja (maximo 2 integrantes).</small></p>

                </button>
            <?php else: ?>
                <button type="submit" class="btn btn-primary  btnGrandeRectangular" data-bs-toggle="modal"
                    data-bs-target="#confirmacionIntegrante"><h3><b>Crear un proyecto</b></h3><br>
                    <p><small>Crea un proyecto de grado indiviual o en pareja (maximo 2 integrantes).</small></p></button>
            <?php endif; ?>
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('proyecto.consultar')): ?>
            <form action="<?php echo e(route('proyecto.indextable')); ?>" method="get">
                <button type="submit" class="btn btn-primary  btnGrandeRectangular">
                    <h3><b>Consultar proyectos</b></h3><br>
                    <p><small>Consulta los proyectos que has creado.</small></p>
                </button>
            </form>
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('proyecto.consultarTodo')): ?>
            <form action="<?php echo e(route('proyecto.indextableAll')); ?>" method="get">
                <button type="submit" class="btn btn-primary  btnGrandeRectangular">Consultar proyectos</button>
            </form>
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('proyecto.consultarDocente')): ?>
            <form action="<?php echo e(route('proyecto.indextableDocente')); ?>" method="get">
                <button type="submit" class="btn btn-primary  btnGrandeRectangular">
                    <h3><b>Proyectos director</b></h3><br>
                    <p><small>Consulta los proyectos que se le han asignado como docente director para su aprobación.</small></p>
                </button>
            </form>
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('proyecto.consultarDocente')): ?>
            <form action="<?php echo e(route('proyecto.indextableJurado')); ?>" method="get">
                <button type="submit" class="btn btn-primary  btnGrandeRectangular">
                    <h3><b>Proyectos Jurados</b></h3><br>
                    <p><small>Consulta los proyectos que se le han asignado como jurado de proyectos de grado.</small></p>
                </button>
            </form>
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('proyecto.consultarComite')): ?>
            <form action="<?php echo e(route('proyecto.indextableComite')); ?>" method="get">
                <button type="submit" class="btn btn-primary  btnGrandeRectangular">
                    <h3><b>Consultar proyectos comite</b></h3><br>
                    <p><small>Visualiza los proyectos de grado como miembro de comite.</small></p>
                </button>
            </form>
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('proyecto.ponderados')): ?>
            <form action="<?php echo e(route('ponderados.index')); ?>" method="get">
                <button type="submit" class="btn btn-primary  btnGrandeRectangular">Ponderados</button>
            </form>
        <?php endif; ?>

    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script>
        function actModalObtNom() { //Activa el modal para buscar un nuevo integrante
            $('#confirmacionIntegrante').modal('hide');
            $('#integrantesModal').modal('show');
        }

        function obtenerNombre() {

            var nombreUsuario = document.getElementById(
                'nombreUsuario'); //etiqueta <p></p> donde se va a mostrar el nombre del usuario buscado en el modal

            var codUsuario = document.getElementById(
                'codUsuario'); //etiqueta <p></p> donde se va a mostrar el codigo del usuario buscado en el modal

            var codigoUsuario = document.getElementById('usuario')
                .value; //obtenemos el codigo de usuario o documento de identidad
            $.ajax({
                url: "<?php echo e(route('buscarIntegrante')); ?>",
                type: 'get',
                data: {
                    documento: codigoUsuario
                },
                dataType: 'json',
                success: function(response) {
                    codUsuario.value = response.codigoUsuario;
                    nombreUsuario.textContent = response.data;

                    if (response.data === "Usuario no encontrado") {
                        $('#btnEnviarSolicitud').css('display', 'none');
                    } else {
                        $('#btnEnviarSolicitud').css('display', 'block');
                    }
                    $('#integrantesModal').modal('hide');
                    $('#buscarIntegranteModal').modal('show');
                },
                error: function() {
                    alert('Hubo un error obteniendo el usuario!');
                }
            });
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\GestionProyectosGrado\resources\views/Layouts/proyecto/index.blade.php ENDPATH**/ ?>