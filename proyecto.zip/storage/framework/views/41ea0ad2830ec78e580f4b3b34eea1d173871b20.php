<div class="modal-dialog">
    <div class="modal-content">
        <div class="modal-header">
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">X</button>
        </div>
        <form action="<?php echo e(route('proyecto.create', '2')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <div class="modal-body">
                <p class="card-text">
                    El codigo del estudiante corresponde a:
                </p>
                <p class="card-text" id="nombreUsuario"></p>
                <input type="hidden" id="codUsuario" name="codUsuario">
                <br>

            </div>
            <div class="modal-footer">

                <button type="submit" class="btn btn-primary text-dark" id="btnEnviarSolicitud">Enviar</button>

            </div>
        </form>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\GestionProyectosGrado\resources\views/components/Modales/buscarIntegranteModal.blade.php ENDPATH**/ ?>