
        <div class="logo col-sm-6">
                <img src="<?php echo e(asset('imgs/logos/escudo.png')); ?>" alt="Logo">
        </div>
        <div class="titulo col-sm-6">
            <h2>SEGETGRA</h2>
        </div>
<?php /**PATH C:\xampp\htdocs\GestionProyectosGrado\resources\views/components/NavbarComponent.blade.php ENDPATH**/ ?>