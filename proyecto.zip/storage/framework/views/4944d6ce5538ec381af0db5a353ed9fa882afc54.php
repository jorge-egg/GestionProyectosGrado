

<?php $__env->startSection('estilos_adicionales'); ?>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/anteproyecto.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('dashboard_content'); ?>
    <?php echo e($valRolComite = false); ?>

    <?php echo e($valCalif = false); ?>

    <br>
    <div style="display: flex; flex-direction:row; justify-content: space-around;">
        <p class="fs-4">Estado: <?php echo e($array['anteproyecto']->estado); ?></p>
        <p class="fs-5">Fecha de habilitación: <?php echo e($array['rangoFecha'][0]); ?> a <?php echo e($array['rangoFecha'][1]); ?></p>
        

    </div><br>
    <div class="card" style="display: flex">
        
        <h5 class="card-title text-center">Crear anteproyecto</h5>
        <div class='card-body'>
            <p class="card-text">

                

            <div>
                <div class="mb-3">
                    <div>
                        <?php $__currentLoopData = $array['integrantes']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $array['integrantes']): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <h1>Integrante <?php echo e($key + 1); ?>: <?php echo e($array['integrantes']->usuarios_user->nombre); ?>

                                <?php echo e($array['integrantes']->usuarios_user->apellido); ?></h1>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <br>
                    
                    <?php if($array['anteproyectoAnterior']->estado == 'Aplazado con modificaciones'): ?>
                        <div class="documentos">
                            <section class="documentosSec" style="text-align: center">

                                <!-- documento del anteproyecto -->
                                <a href="<?php echo e(route('anteproyecto.verpdf', ['nombreArchivo' => $array['anteproyectoAnterior']->documento, 'ruta' => '1'])); ?>"
                                    target="_blank" class="btn btn-warning"><i
                                        class="bi bi-file-earmark-pdf-fill"><?php echo e(' ' . $array['anteproyectoAnterior']->documento); ?>

                                        --
                                        documento de anteproyecto</i></a>
                            </section>
                            <section class="documentosSec" style="text-align: center">
                                <!-- carta del director -->
                                <a href="<?php echo e(route('anteproyecto.verpdf', ['nombreArchivo' => $array['anteproyectoAnterior']->cartaDirector, 'ruta' => '2'])); ?>"
                                    target="_blank" class="btn btn-warning"><i
                                        class="bi bi-file-earmark-pdf-fill"><?php echo e(' ' . $array['anteproyectoAnterior']->cartaDirector); ?>

                                        -- carta
                                        del director</i></a>
                            </section>
                        </div>
                        <div class="input-group">
                            <span class="input-group-text">Observación de los documentos anteriores</span>
                            <textarea class="form-control" aria-label="With textarea" disabled><?php echo e($array['anteproyectoAnterior']->observaDocent); ?></textarea>
                        </div><br>

                    <?php endif; ?>

                    <?php if(!$array['rangoFecha'][2]): ?>
                        <h2 style="color: red">Por favor espere la proxima fecha habilitada para esta fase</h2>
                    <?php elseif(
                        ($array['docExist1'] == null && $array['docExist2'] == null) ||
                            $array['anteproyecto']->estado == 'Aplazado con modificaciones'): ?>
                        <p style="color: red">El documento no ha sido cargado. </p>
                        <form action="<?php echo e(route('anteproyecto.store')); ?>" method="post" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" value="<?php echo e($array['idProyecto']); ?>" name='idProyecto'>
                            <input type="hidden" value="<?php echo e($array['anteproyecto']->juradoUno); ?>" name="juradoUnoInp">
                            <input type="hidden" value="<?php echo e($array['anteproyecto']->juradoDos); ?>" name="juradoDosInp">
                            <input type="hidden" value="<?php echo e($array['anteproyecto']->estadoJUno); ?>" name="estadoJUno">
                            <input type="hidden" value="<?php echo e($array['anteproyecto']->estadoJDos); ?>" name="estadoJDos">
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('propuesta.agregar')): ?>
                                <div class="documentos">
                                    <section class="documentosSec">
                                        <label for="docAnt" class="form-label">Documento de anteproyecto</label>
                                        <input class="form-control input-file <?php $__errorArgs = ['docAnteProy'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            type="file" id="docAnt" name="docAnteProy">
                                        <?php $__errorArgs = ['docAnteProy'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="alert alert-danger"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </section>
                                    <section class="documentosSec">
                                        <label for="docDir" class="form-label">Carta de aprobación Director</label>
                                        <input class="form-control input-file <?php $__errorArgs = ['docDir'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            type="file" id="docDir" name="docDir">
                                        <?php $__errorArgs = ['docDir'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="alert alert-danger"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </section>
                                </div>
                                <button type="submit" id="buttonToCreatePropuesta" class="btn"
                                    style="background:#003E65; color:#fff">Agregar</button>
                            <?php endif; ?>
                        </form>
                    <?php elseif($array['docExist1'] != null && $array['docExist2'] != null): ?>
                        <p style="display: none"><?php echo e($valRolComite = true); ?></p>
                        <div class="documentos">
                            <section class="documentosSec" style="text-align: center">

                                <!-- documento del anteproyecto -->
                                <a href="<?php echo e(route('anteproyecto.verpdf', ['nombreArchivo' => $array['docExist1'], 'ruta' => '1'])); ?>"
                                    target="_blank" class="btn btn-warning"><i
                                        class="bi bi-file-earmark-pdf-fill"><?php echo e(' ' . $array['docExist1']); ?> --
                                        documento de anteproyecto</i></a>
                            </section>
                            <section class="documentosSec" style="text-align: center">
                                <!-- carta del director -->
                                <a href="<?php echo e(route('anteproyecto.verpdf', ['nombreArchivo' => $array['docExist2'], 'ruta' => '2'])); ?>"
                                    target="_blank" class="btn btn-warning"><i
                                        class="bi bi-file-earmark-pdf-fill"><?php echo e(' ' . $array['docExist2']); ?> -- carta
                                        del director</i></a>
                            </section>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('propuesta.agregar')): ?>
                                <p style="color: red">Por favor espere a que el director del proyecto califique los documentos
                                    cargados</p>
                            <?php endif; ?>
                        </div>
                        <?php
                            $aprobDocent =
                                $array['anteproyecto'] == null ? false : $array['anteproyecto']->aprobacionDocen;
                        ?>


                        <form method="post">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" value="<?php echo e($array['idProyecto']); ?>" name='idProyecto'>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('anteproyecto.aprobarDocumento')): ?>
                                <p style="display: none"><?php echo e($valCalif = true); ?></p>
                                <?php if($array['valDocAsig']): ?>
                                    <p style="display: <?php echo e($aprobDocent == '-1' ? 'block' : 'none'); ?>"><b>Nota: </b>Estimado
                                        profesor, para nombrar jurados al proyecto usted debe dar su
                                        aprobación al documento.</p>
                                    <br>
                                    <div class="input-group">
                                        <span class="input-group-text">Observaciones</span>
                                        <textarea class="form-control" aria-label="With textarea" name="ObsDocent"
                                            <?php echo e($aprobDocent == '-1' ? '' : 'disabled'); ?>><?php echo e($array['anteproyecto']->observaDocent); ?></textarea>
                                    </div><br>
                                    <div class="form-check form-switch"
                                        style="display: <?php echo e($aprobDocent == '-1' ? 'block' : 'none'); ?>"
                                        <?php echo e($aprobDocent == '-1' ? '' : 'disabled'); ?>>
                                        <input class="form-check-input" type="checkbox" id="flexSwitchCheckDefault"
                                            name="switchAprobDoc">
                                        <label class="form-check-label" for="flexSwitchCheckDefault">Aprobación del
                                            docente</label>
                                    </div><br>
                                    <button class="btn"
                                        style="background:#003E65; color:#fff; margin-bottom: 10px; display: <?php echo e($aprobDocent == '-1' ? 'block' : 'none'); ?>"
                                        <?php echo e($aprobDocent == '-1' ? '' : 'disabled'); ?>

                                        formaction="<?php echo e(route('anteproyecto.aprobDoc')); ?>">Enviar actualizacion de estado de
                                        aprobación del documento</button>
                                    <?php if($aprobDocent == '1'): ?>
                                        <p style="color: red">Los documentos NO fueron aprobados por el director del proyecto
                                        </p>
                                    <?php elseif($aprobDocent == '2' || ($aprobDocent == '2' && $array['anteproyecto']->estado == 'Aplazado con modificaciones')): ?>
                                        <p style="color: rgb(0, 62, 101)"><b>Los documentos fueron aprobados por el director del
                                                proyecto</b></p>
                                    <?php endif; ?>
                                <?php endif; ?>
                            <?php endif; ?>
                        </form>
                </div>
            </div>
        </div>
    </div>
    <br>
    <div class="card" style="display: <?php echo e($aprobDocent == '2' ? 'block' : 'none'); ?>">
        <h5 class="card-title text-center">Jurados</h5>

        <div class='card-body' style="text-align: center">
            <p
                style="color: red; display:<?php echo e($array['anteproyecto']->juradoUno == '-1' || $array['anteproyecto']->juradoDos == '-1' ? 'block' : 'none'); ?>">
                Por favor espere a que se le asignen los jurados a la fase de anteproyecto</p>
            <p
                style="color: red; display:<?php echo e($array['anteproyecto']->juradoUno != '-1' && $array['anteproyecto']->juradoDos != '-1' ? 'block' : 'none'); ?>">
                Los jurados fueron asignados exitosamente</p>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('anteproyecto.verJurados')): ?>
                <?php
                    $JuradoUno =
                        $array['anteproyecto']->juradoUno == '-1'
                            ? (object) ['nombre' => 'Sin asignar', 'apellido' => '']
                            : App\Models\UsuariosUser::where('numeroDocumento', $array['anteproyecto']->juradoUno)
                                ->select('nombre', 'apellido')
                                ->first();
                    $JuradoDos =
                        $array['anteproyecto']->juradoDos == '-1'
                            ? (object) ['nombre' => 'Sin asignar', 'apellido' => '']
                            : App\Models\UsuariosUser::where('numeroDocumento', $array['anteproyecto']->juradoDos)
                                ->select('nombre', 'apellido')
                                ->first();

                ?>
                <section style="display: flex; flex-direction: row; text-align: center; justify-content: center">

                    <p style="color: red">Jurado 1: <?php echo e($JuradoUno->nombre . ' ' . $JuradoUno->apellido); ?></p>
                    <button type="button" id="SelectJ1" data-bs-toggle="modal" data-bs-target="#buscarDocente"
                        style="height: 30px; width: 30px; margin-left: 10px; display: <?php echo e($array['anteproyecto']->juradoUno != '-1' ? 'block' : 'none'); ?>">
                        <img src="<?php echo e(asset('imgs/icons/edit.png')); ?>" class = "bi bi-pencil-square">
                    </button>
                </section>
                <section style="display: flex; flex-direction: row; text-align: center; justify-content: center">

                    <p style="color: red">Jurado 2: <?php echo e($JuradoDos->nombre . ' ' . $JuradoDos->apellido); ?></p>
                    <button type="button" id="SelectJ2" data-bs-toggle="modal" data-bs-target="#buscarDocente"
                        style="height: 30px; width: 30px; margin-left: 10px; display: <?php echo e($array['anteproyecto']->juradoDos != '-1' ? 'block' : 'none'); ?>">
                        <img src="<?php echo e(asset('imgs/icons/edit.png')); ?>" class = "bi bi-pencil-square">
                    </button>
                </section>
                <div class="modal fade" tabindex="-1" id="buscarDocente" role="dialog"
                    aria-labelledby="exampleModalLabel" aria-hidden="true">

                    <?php $__env->startComponent('components.Modales.buscarDocente', [
                        'docentes' => $miembrosDocente['docentes'],
                        'idProyecto' => $miembrosDocente['idProyecto'],
                        'fase' => 'anteproyecto',
                    ]); ?>
                    <?php echo $__env->renderComponent(); ?>
                </div>
                <?php
                    $habilitarButtonJ =
                        $array['anteproyecto']->juradoUno != '-1' && $array['anteproyecto']->juradoDos != '-1'
                            ? 'none'
                            : 'block';
                ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('anteproyecto.asigJurados')): ?>
                    <button type="button" data-bs-toggle="modal" data-bs-target="#buscarDocente" class="btn"
                        style="background:#003E65; color:#fff; width: 100%; display: <?php echo e($habilitarButtonJ); ?>">Seleccionar
                        jurados</button>
                <?php endif; ?>
            <?php endif; ?>
        </div>
    </div>
    <br>

    <?php if($aprobDocent == '2' || $array['anteproyectoAnterior']->estado == 'Aplazado con modificaciones'): ?>

        <div class="card"
            style="display:<?php echo e($array['anteproyecto']->juradoUno != '-1' || $array['anteproyecto']->juradoDos != '-1' || $array['anteproyectoAnterior']->estado == 'Aplazado con modificaciones' ? 'flex' : 'none'); ?>">

            <ul class="nav nav-tabs">
                <li class="nav-item"
                    style="display: <?php echo e($array['anteproyecto']->juradoDos == App\Models\UsuariosUser::where('usua_users', auth()->id())->whereNull('deleted_at')->first()->numeroDocumento ? 'none' : 'block'); ?>">
                    <a class="nav-link active" aria-current="page" id="juradoUnoButton" style="cursor: pointer;">Jurado
                        1</a>
                </li>
                <li class="nav-item"
                    style="display: <?php echo e($array['anteproyecto']->juradoUno == App\Models\UsuariosUser::where('usua_users', auth()->id())->whereNull('deleted_at')->first()->numeroDocumento ? 'none' : 'block'); ?>">
                    <a class="nav-link" aria-current="page" id="juradoDosButton" style="cursor: pointer;">Jurado 2</a>
                </li>
            </ul>
            <form action="<?php echo e(route('anteproyecto.store')); ?>" method='POST'>
                <?php echo csrf_field(); ?>
                <input type="hidden" id="inputJurado" name="numeroJurado"
                    value="<?php echo e($array['anteproyecto']->juradoDos == App\Models\UsuariosUser::where('usua_users', auth()->id())->whereNull('deleted_at')->first()->numeroDocumento ? '1' : ($array['anteproyecto']->juradoUno == App\Models\UsuariosUser::where('usua_users', auth()->id())->whereNull('deleted_at')->first()->numeroDocumento ? '0' : '0')); ?>">
                <section id="j1"
                    style="display: <?php echo e($array['anteproyecto']->juradoDos == App\Models\UsuariosUser::where('usua_users', auth()->id())->whereNull('deleted_at')->first()->numeroDocumento ? 'none' : ($array['anteproyecto']->juradoDos != App\Models\UsuariosUser::where('usua_users', auth()->id())->whereNull('deleted_at')->first()->numeroDocumento && $array['anteproyecto']->juradoUno != App\Models\UsuariosUser::where('usua_users', auth()->id())->whereNull('deleted_at')->first()->numeroDocumento ? 'block' : 'block')); ?>">
                    <?php $__env->startComponent('components.anteproyecto.VistaJurados', [
                        'array' => $array,
                        'valRolComite' => $valRolComite,
                        'jurado' => 0,
                        'fase' => 'anteproyecto',
                        'idFase' => $array['anteproyecto']->idAnteproyecto,
                    ]); ?>
                    <?php echo $__env->renderComponent(); ?>
                </section>
                <section id="j2"
                    style="display: <?php echo e($array['anteproyecto']->juradoUno == App\Models\UsuariosUser::where('usua_users', auth()->id())->whereNull('deleted_at')->first()->numeroDocumento ? 'none' : ($array['anteproyecto']->juradoDos != App\Models\UsuariosUser::where('usua_users', auth()->id())->whereNull('deleted_at')->first()->numeroDocumento && $array['anteproyecto']->juradoUno != App\Models\UsuariosUser::where('usua_users', auth()->id())->whereNull('deleted_at')->first()->numeroDocumento ? 'none' : 'block')); ?>">
                    <?php $__env->startComponent('components.anteproyecto.VistaJurados', [
                        'array' => $array,
                        'valRolComite' => $valRolComite,
                        'jurado' => 1,
                        'fase' => 'anteproyecto',
                        'idFase' => $array['anteproyecto']->idAnteproyecto,
                    ]); ?>
                    <?php echo $__env->renderComponent(); ?>
                </section>
            </form>


        </div>
    <?php endif; ?>
<?php else: ?>
    <p style="color: red;">
        <?php echo e($array['anteproyecto']->aprobacionDocen == '1'
            ? 'El director no aprobo el documento'
            : ($array['anteproyecto']->aprobacionDocen == '-1'
                ? 'No se podra calificar el anteproyecto hasta que el director apruebe el
                                                                                                                                                                                                                                                                                                                                                                                documento'
                : '')); ?>

    </p>


    <?php endif; ?>

    </div>




    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const btnSelectJurado1 = document.getElementById('SelectJ1');
            const btnSelectJurado2 = document.getElementById('SelectJ2');
            const JIdentificador = document.getElementById('JIdentificador');
            const enlace1 = document.getElementById('juradoUnoButton');
            const enlace2 = document.getElementById('juradoDosButton');
            const inputJurado = document.getElementById('inputJurado');
            const secJ1 = document.getElementById('j1');
            const secJ2 = document.getElementById('j2');

            if (inputJurado.value === '0') {
                secJ2.querySelectorAll('textarea').forEach(textarea => {
                    textarea.name = 'inactive_' + textarea.name;
                });

                secJ1.querySelectorAll('textarea').forEach(textarea => {
                    textarea.name = textarea.name.replace(/^inactive_/, '');
                });
            } else if (inputJurado.value === '1') {
                secJ1.querySelectorAll('textarea').forEach(textarea => {
                    textarea.name = 'inactive_' + textarea.name;
                });

                secJ2.querySelectorAll('textarea').forEach(textarea => {
                    textarea.name = textarea.name.replaceAll('inactive_', '');
                });
            }

            enlace1.addEventListener('click', function(event) {
                event.preventDefault();

                inputJurado.value = '0';

                enlace1.classList.add('active');
                enlace2.classList.remove('active');

                secJ1.style.display = 'block';
                secJ2.style.display = 'none';
            });

            enlace2.addEventListener('click', function(event) {
                event.preventDefault();

                inputJurado.value = '1';

                enlace2.classList.add('active');
                enlace1.classList.remove('active');

                secJ2.style.display = 'block';
                secJ1.style.display = 'none';
            });

            btnSelectJurado1.addEventListener('click', function(event) {
                event.preventDefault();
                document.querySelectorAll('.JIdentificador').forEach(function(input) {
                    input.value = '1';
                });
            });

            btnSelectJurado2.addEventListener('click', function(event) {
                event.preventDefault();
                document.querySelectorAll('.JIdentificador').forEach(function(input) {
                    input.value = '2';
                });
            });


        });
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\GestionProyectosGrado\resources\views/Layouts/anteproyecto/create.blade.php ENDPATH**/ ?>