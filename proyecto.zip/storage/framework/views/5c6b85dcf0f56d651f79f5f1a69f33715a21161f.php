<?php $__env->startSection('dashboard_content'); ?>
<div class="card text-center">
    <div class="card-header">
        Estadísticas
    </div>
    <div class="card-body">
        <form method="GET" action="<?php echo e(route('charts.index')); ?>">
            <div class="row mb-4">
                <div class="col-md-3">
                    <input type="date" name="start_date" class="form-control" value="<?php echo e($startDate); ?>">
                </div>
                <div class="col-md-3">
                    <input type="date" name="end_date" class="form-control" value="<?php echo e($endDate); ?>">
                </div>
                <div class="col-md-3">
                    <button type="submit" class="btn btn-primary">Filtrar</button>
                </div>
            </div>
        </form>
        <div class="row">
            <div class="col-md-2">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Total Proyectos</h5>
                        <p class="card-text"><?php echo e($totalProyectos); ?></p>
                    </div>
                </div>
            </div>
            <div class="col-md-2">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Total Sustentaciones</h5>
                        <p class="card-text"><?php echo e($totalSustentaciones); ?></p>
                    </div>
                </div>
            </div>
            <div class="col-md-2">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Total Proyectos Finales</h5>
                        <p class="card-text"><?php echo e($totalProyectosFinales); ?></p>
                    </div>
                </div>
            </div>
            <div class="col-md-2">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Total Anteproyectos</h5>
                        <p class="card-text"><?php echo e($totalAnteproyectos); ?></p>
                    </div>
                </div>
            </div>
            <div class="col-md-2">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Total Propuestas</h5>
                        <p class="card-text"><?php echo e($totalPropuestas); ?></p>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-6">
                <h1><?php echo e($chart1->options['chart_title']); ?></h1>
                <?php echo $chart1->renderHtml(); ?>

            </div>
            <div class="col-md-3">
                <h1><?php echo e($chart2->options['chart_title']); ?></h1>
                <?php echo $chart2->renderHtml(); ?>

            </div>
            <div class="col-md-3">
                <h1><?php echo e($chart3->options['chart_title']); ?></h1>
                <?php echo $chart3->renderHtml(); ?>

            </div>
            <div class="col-md-3">
                <h1><?php echo e($chart4->options['chart_title']); ?></h1>
                <?php echo $chart4->renderHtml(); ?>

            </div>
            <div class="col-md-3">
                <h1><?php echo e($chart5->options['chart_title']); ?></h1>
                <?php echo $chart5->renderHtml(); ?>

            </div>
            <div class="col-md-3">
                <h1><?php echo e($chart6->options['chart_title']); ?></h1>
                <?php echo $chart6->renderHtml(); ?>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <?php echo $chart1->renderChartJsLibrary(); ?>

    <?php echo $chart1->renderJs(); ?>

    <?php echo $chart2->renderJs(); ?>

    <?php echo $chart3->renderJs(); ?>

    <?php echo $chart4->renderJs(); ?>

    <?php echo $chart5->renderJs(); ?>

    <?php echo $chart6->renderJs(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\GestionProyectosGrado\resources\views/Layouts/Charts/index.blade.php ENDPATH**/ ?>