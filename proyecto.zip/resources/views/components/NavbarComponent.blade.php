
        <div class="logo col-sm-6">
                <img src="{{ asset('imgs/logos/escudo.png') }}" alt="Logo">
        </div>
        <div class="titulo col-sm-6">
            <h2>SEGETGRA</h2>
        </div>
