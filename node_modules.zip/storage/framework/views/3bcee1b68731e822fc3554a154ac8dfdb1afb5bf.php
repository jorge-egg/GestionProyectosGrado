<?php $__env->startSection('estilos_adicionales'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/coloresBtnCampos.css')); ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.3.0/css/bootstrap.min.css"
        rel='stylesheet'>
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/dataTables.bootstrap5.min.css" rel='stylesheet'>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('dashboard_content'); ?>
    <h1>usuarios</h1>
    <br>
    <?php if(session()->has('success')): ?>
        <div class= 'alert alert-success'>
            <?php echo e(session()->get('success')); ?>

        </div>
    <?php endif; ?>
    <div class='col col-md-6 '>
        <a href="<?php echo e(route('usuarios.index', ['view_deleted' => 'DeletedRecords'])); ?>"class='btn btn-warning'>Consultar
            usuarios
            eliminados</a>
    </div>
    <br>
    <div class='col col-md-6 '>
        <a href="<?php echo e(route('usuarios.create')); ?>" class='btn btn-warning'>crear usuario</a>
</div>
    <table class="table table-hover shadow-lg mt-4" style="width:100%" id='table-js'>
        <thead class='bg-table'>
            <tr>
                <th scope="col">Documento</th>
                <th scope="col">Nombre</th>
                <th scope="col">Apellido</th>
                <th scope="col">Email</th>
                <th scope="col">Telefono</th>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('usuario.bloquear')): ?>
                    <th scope="col"></th>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('usuario.editar')): ?>
                    <th scope="col"></th>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('usuario.eliminar')): ?>
                    <th scope="col"></th>
                <?php endif; ?>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th><?php echo e($usuario->numeroDocumento); ?></th>
                    <td><?php echo e($usuario->nombre); ?></td>
                    <td><?php echo e($usuario->apellido); ?></td>
                    <td><?php echo e($usuario->email); ?></td>
                    <td><?php echo e($usuario->numeroCelular); ?></td>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('usuario.bloquear')): ?>
                        <td>
                            <form action="<?php echo e(route('usuarios.cambioEstado', $usuario->numeroDocumento)); ?>" method="post">
                                <?php echo csrf_field(); ?>

                                <?php if($usuario->estado == 1): ?>
                                    <button type="submit" class="btn btn-primary text-dark"><i
                                            class='bx
                                    bxs-user-x'></i>Deshabilitar</button>
                                <?php else: ?>
                                    <button type="submit" class="btn" style="background:#003E65; color:#fff"><i
                                            class="btn " style="background:#003E65; color:#fff">habilitar</i></button>
                                <?php endif; ?>
                            </form>
                        </td>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('usuario.editar')): ?>
                        <td>

                            <form action="<?php echo e(route('usuarios.edit', $usuario->numeroDocumento)); ?>" method="post">
                                <?php echo csrf_field(); ?>

                                <button type="submit" class="btn btn-warning">Editar</button>

                            </form>


                        </td>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('usuario.eliminar')): ?>
                        <td>



                            <?php if(request()->has('view_deleted')): ?>
                                <a href="<?php echo e(route('usuarios.restore', $usuario->numeroDocumento)); ?>" class="btn "
                                    style="background:#003E65; color:#fff">Restablecer</a>
                            <?php else: ?>
                                <form action="<?php echo e(route('usuarios.destroy', $usuario->numeroDocumento)); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <button type="submit" class="btn btn-warning">Eliminar</button>
                                </form>
                            <?php endif; ?>

                        </td>
                    <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php $__env->startSection('js'); ?>
    <script src="https://code.jquery.com/jquery-3.7.0.js"></script>
    <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.6/js/dataTables.bootstrap5.min.js"></script>
<?php $__env->stopSection(); ?>
<script>
    let table = new DataTable('#usuario');
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\GestionProyectosGrado\resources\views/Layouts/usuarios/read.blade.php ENDPATH**/ ?>