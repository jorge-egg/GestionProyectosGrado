
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Docentes</h5>
                <a href="<?php echo e(url()->previous()); ?>" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </a>
            </div>
            <div class="modal-body">
                <table class="table">
                    <thead>
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">Docente</th>
                            <th scope="col">Sede</th>
                            <th scope="col"></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                            $contador = 0;
                        ?>
                        <?php $__currentLoopData = $docentes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $docente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $contador++;
                            ?>
                            <tr>
                                <form method="post">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" value=<?php echo e($idProyecto); ?> name="idProyecto">
                                    <input type="hidden" value=<?php echo e($docente->numeroDocumento); ?>

                                        name="numeroDocumento">
                                    <th scope="row"><?php echo e($contador); ?></th>
                                    <td><?php echo e($docente->nombre . ' ' . $docente->apellido); ?></td>
                                    <td><?php echo e($docente->sede); ?></td>
                                    <td><button formaction="<?php echo e(route('propuesta.asigDocente')); ?>" type="submit"><i class="bi bi-person-fill-add"></i></button></td>
                                </form>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <div class="modal-footer">
                <a href="<?php echo e(url()->previous()); ?>" class="btn btn-secondary text-dark" data-dismiss="modal">Cerrar</a>
            </div>
        </div>
    </div>

<?php /**PATH C:\xampp\htdocs\GestionProyectosGrado\resources\views/components/Modales/buscarDocente.blade.php ENDPATH**/ ?>