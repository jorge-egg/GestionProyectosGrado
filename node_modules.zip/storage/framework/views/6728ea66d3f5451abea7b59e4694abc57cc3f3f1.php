
<?php $__env->startSection('estilos_adicionales'); ?>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.3.0/css/bootstrap.min.css" rel='stylesheet'>
<link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/dataTables.bootstrap5.min.css" rel='stylesheet'>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('dashboard_content'); ?>

<h1>Proyectos</h1>
<table class="table table-hover shadow-lg mt-4" style="width:100%" id='table-js'>
        <thead>
            <tr>
                <th scope="col">estado</th>
                <th scope="col">codigo proyecto</th>
                <th scope="col"></th>
                <th scope="col"></th>
                <th scope="col"></th>
                <th scope="col"></th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $proyectos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $proyecto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php if( $proyecto->estado ): ?>
                        Activo
                        <?php else: ?>
                        Finalizado
                    <?php endif; ?></td>
                    <td><?php echo e($proyecto->codigoproyecto); ?></td>
                    <td>
                        <form action="<?php echo e(route('propuesta.create', $proyecto->idProyecto)); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="idProyecto" value="<?php echo e($proyecto->idProyecto); ?>">
                            <button type="submit" class='btn btn-primary text-dark'>Propuesta</button>
                        </form>
                    </td>
                    <td>
                        <form action="#" >
                            <?php echo csrf_field(); ?>
                            <button type="submit" class="btn" style="background:#003E65; color:#fff">Anteproyecto</button>
                        </form>
                    </td>
                    <td>
                        <form action="#" >
                            <?php echo csrf_field(); ?>
                            <button type="submit" class="btn" style="background:#003E65; color:#fff">Proyecto final</button>
                        </form>
                    </td>
                    <td>
                        <form action="#" >
                            <?php echo csrf_field(); ?>
                            <button type="submit" class="btn" style="background:#003E65; color:#fff">Sustentación</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php $__env->startSection('js'); ?>
<script src="https://code.jquery.com/jquery-3.7.0.js"></script>
<script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.13.6/js/dataTables.bootstrap5.min.js"></script>
<?php $__env->stopSection(); ?>
<script>
    let table = new DataTable('#proy');
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\GestionProyectosGrado\resources\views/Layouts/proyecto/tableindex.blade.php ENDPATH**/ ?>