<?php $__env->startSection('dashboard_content'); ?>
    <br>
    <form action="<?php echo e(route('propuesta.store')); ?>" method='POST'>
        <div style="display: flex; flex-direction:row; justify-content: space-around">

            <p class="fs-4">Estado: <?php echo e($propuestaAnterior->estado); ?></p>
            <p class="fs-5">Fecha de habilitación: <?php echo e($rangoFecha[0]); ?> a <?php echo e($rangoFecha[1]); ?></p>
            <?php if($estadoButton): ?>
                <button type="submit" class="btn btn-outline-dark" formaction="<?php echo e(route('propuesta.createAnterior')); ?>"><i
                        class="bi bi-arrow-bar-left"></i>Propuesta anterior</button>
            <?php elseif(!$estadoButton): ?>
                <button type="submit" class="btn btn-outline-dark"
                    formaction="<?php echo e(route('propuesta.create', $idProyecto)); ?>">Propuesta superior<i
                        class="bi bi-arrow-bar-left"></i></button>
            <?php endif; ?>
        </div><br>
        <div class="card">
            <h5 class="card-title text-center">Crear propuesta</h5>
            <div class='card-body'>
                <p class="card-text">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('propuesta.calificar')): ?>
                        <button type="button" id="calificar" class="btn" style="background:#003E65; color:#fff"
                            onclick="mostrarCamposCalificacion()">Calificar</button>
                    <?php endif; ?>
                    <?php if($propuestaAnterior->estado == 'Aprobado'): ?>
                        <span style="color: red;">Esta fase del proyecto ha sido completada, pase a la siguiente
                            fase.</span>
                    <?php elseif($propuestaAnterior->estado == 'Aplazado con modificaciones'): ?>
                        <span style="color: red;">Tiene 10 días hábiles para enviar la corrección, después de eso no tendrá
                            más oportunidades.</span>
                    <?php elseif($propuestaAnterior->estado == 'Rechazado'): ?>
                        <span style="color: red;">Su proyecto finalizó. Para poder enviar otra propuesta, deberá crear otro
                            proyecto.</span>
                    <?php endif; ?>

                    <?php echo csrf_field(); ?>
                    <input type="hidden" value="<?php echo e($idProyecto); ?>" name='idProyecto'>
                    <input type="hidden" value="<?php echo e($propuestaAnterior->idPropuesta); ?>" name='idPropuesta'>
                <div>
                    <label for="titleForPropuestaId">Titulo</label>
                    <div class="input-group mb-3">
                        <input type="text" name='titulo' onchange="validarCampos()" id="titleForPropuestaId"
                            oninput="limitarLongitud( this.id, 25, 'contadorTitle' )"
                            class='form-control campo-deshabilitar' value = "<?php echo e($propuestaAnterior->titulo); ?>" required
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('propuesta.calificar')): ?>
                                disabled
                            <?php endif; ?>>
                        <span class="input-group-text" id="basic-addon2">
                            <p class="fw-bold"><?php echo e($calificacion[0]); ?></p>
                        </span>
                    </div>
                    <p>Longitud máxima: <span id="contadorTitle"></span></p>
                    <?php $__env->startComponent('components.calificacionObser', [
                        'nameSelect' => 'tituloCalificacion',
                        'nameTextArea' => 'tituloObservacion',
                        'obsArray' => $observaciones[0],
                    ]); ?>
                    <?php echo $__env->renderComponent(); ?>
                    <br>
                </div>
                <div>
                    <label>Linea de investigación</label>
                    <div class="input-group mb-3">
                        <input type="text" name='linea_invs' onchange="validarCampos()"
                            class='form-control campo-deshabilitar' value = "<?php echo e($propuestaAnterior->linea_invs); ?>" required
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('propuesta.calificar')): ?>
                            disabled
                        <?php endif; ?>>
                        <span class="input-group-text" id="basic-addon2">
                            <p class="fw-bold"><?php echo e($calificacion[1]); ?></p>
                        </span>
                    </div>
                    <?php $__env->startComponent('components.calificacionObser', [
                        'nameSelect' => 'lineaCalificacion',
                        'nameTextArea' => 'lineaObservacion',
                        'obsArray' => $observaciones[1],
                    ]); ?>
                    <?php echo $__env->renderComponent(); ?>
                </div>
                <br>
                <div class="mb-3">
                    <label class="form-label">Descripción del problema</label>
                    <div class="input-group mb-3">
                        <textarea class="form-control auto-expand campo-deshabilitar" name="desc_problema" onchange="validarCampos()"
                            id="descriptionPropuestaId" oninput="limitarLongitud( this.id, 600, 'DescripcionContador' )" class='form-control'
                            placeholder="Descripción del problema" required
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('propuesta.calificar')): ?>
                            disabled
                        <?php endif; ?>><?php echo e($propuestaAnterior->desc_problema); ?></textarea>
                        <span class="input-group-text" id="basic-addon2">
                            <p class="fw-bold"><?php echo e($calificacion[2]); ?></p>
                        </span>
                    </div>
                    <p>Longitud máxima: <span id="DescripcionContador"></span></p>
                    <?php $__env->startComponent('components.calificacionObser', [
                        'nameSelect' => 'descProbCalificacion',
                        'nameTextArea' => 'descProbObservacion',
                        'obsArray' => $observaciones[2],
                    ]); ?>
                    <?php echo $__env->renderComponent(); ?>
                </div>
                <br>
                <div class="mb-3">
                    <label class="form-label">Objetivo general</label>
                    <div class="input-group mb-3">
                        <textarea class="form-control auto-expand campo-deshabilitar" name="obj_general" onchange="validarCampos()"
                            id="objectiveGeneralId" oninput="limitarLongitud( this.id, 25, 'ObjetivoGeneralContador' )" class='form-control'
                            placeholder="Objetivo general" required
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('propuesta.calificar')): ?>
                            disabled
                        <?php endif; ?>><?php echo e($propuestaAnterior->obj_general); ?></textarea>
                        <span class="input-group-text" id="basic-addon2">
                            <p class="fw-bold"><?php echo e($calificacion[3]); ?></p>
                        </span>
                    </div>
                    <p>Longitud máxima: <span id="ObjetivoGeneralContador"></span></p>
                    <?php $__env->startComponent('components.calificacionObser', [
                        'nameSelect' => 'objGenCalificacion',
                        'nameTextArea' => 'objGenObservacion',
                        'obsArray' => $observaciones[3],
                    ]); ?>
                    <?php echo $__env->renderComponent(); ?>
                </div>
                <br>
                <div class="mb-3">
                    <label class="form-label">Objetivos específicos</label>
                    <div class="input-group mb-3">
                        <textarea class="form-control auto-expand campo-deshabilitar" name="obj_especificos" onchange="validarCampos()"
                            class='form-control' placeholder="Objetivos específicos" required
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('propuesta.calificar')): ?>
                            disabled
                        <?php endif; ?>><?php echo e($propuestaAnterior->obj_especificos); ?></textarea>
                        <span class="input-group-text" id="basic-addon2">
                            <p class="fw-bold"><?php echo e($calificacion[4]); ?></p>
                        </span>
                    </div>
                    <?php $__env->startComponent('components.calificacionObser', [
                        'nameSelect' => 'objEspCalificacion',
                        'nameTextArea' => 'objEspObservacion',
                        'obsArray' => $observaciones[4],
                    ]); ?>
                    <?php echo $__env->renderComponent(); ?>
                    <br>
                    <div class="mb-3">
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('propuesta.agregar')): ?>
                            <button id="buttonToCreatePropuesta" class="btn"
                                style="background:#003E65; color:#fff">Agregar</button>
                        <?php endif; ?>


                        <button id="buttonEnviarCalificacion"
                            formaction="<?php echo e($validarCalificacion ? route('observaciones.store') : route('observaciones.update')); ?>"
                            class="btn" style="background:#003E65; color:#fff; display:none">Enviar calificación</button>

                        </p>
                    </div>
                </div>
    </form>

<?php $__env->startSection('js'); ?>

    <script>
        function mostrarCamposCalificacion(){
            const camposCalificacion = document.querySelectorAll('.campos-calificacion');

                camposCalificacion.forEach(campos => {
                    campos.style.display = 'flex';
                    // Agregar el atributo required a los campos dentro de la sección
                    campos.querySelectorAll('input, textarea').forEach(campo => {
                        campo.required = true;
                        campo.disabled = false; // Habilitar campos al mostrar
                    });
                });

                // Mostrar el botón de enviar calificación
                buttonEnviarCalificacion.style.display = 'inline-block';
                buttonToCreatePropuesta.style.display = 'none';
        }

        const limitarLongitud = (id, longitud, contadorId) => {
            const input = document.getElementById(id);
            const contador = document.getElementById(contadorId);

            if (input.value.length <= 0) {
                contador.textContent = 0;
                return;
            }

            const maxPalabras = longitud; // Define la cantidad máxima de palabras aquí

            let palabras = input.value.split(' ');

            if (palabras.length > maxPalabras) {
                contador.textContent = "Limite de palabras excedido.";
                contador.style.color = 'red';
                palabras.pop();
                input.value = palabras.join(' ');
                var camposVacios = true;

            } else if (palabras.length <= maxPalabras) {
                contador.textContent = palabras.length;
                var camposVacios = false;
                contador.style.color = 'black';
            }

            const button = document.getElementById('buttonToCreatePropuesta');
            button.disabled = camposVacios;
        }

        const validarCampos = () => {
            const inputs = document.querySelectorAll('input[required], textarea[required]');
            let camposVacios = false;

            inputs.forEach(input => {
                if (input.value.trim() === '') {
                    camposVacios = true;
                } else {
                    camposVacios = false;
                }
            });

            const button = document.getElementById('buttonToCreatePropuesta');
            button.disabled = camposVacios;
        }

        window.addEventListener('load', validarCampos);

        document.addEventListener('DOMContentLoaded', function() {
            const buttonToCreatePropuesta = document.getElementById('buttonToCreatePropuesta');
            const buttonEnviarCalificacion = document.getElementById('buttonEnviarCalificacion');
            const buttonCalificar = document.getElementById('calificar');

            // Obtener el estado de la propuesta
            const estadoPropuesta = "<?php echo e($propuestaAnterior->estado); ?>";
            var rangoFecha = "<?php echo e($rangoFecha[2]); ?>";

            // Verificar el estado y deshabilitar campos y botón si es necesario
            if (estadoPropuesta === 'Aprobado' || !rangoFecha || estadoPropuesta === 'Rechazado' ||
                estadoPropuesta === 'pendiente') {
                deshabilitarCamposYBoton();
            } else if (estadoPropuesta === 'activo') {
                ocultarBotonCalificar();
            }


            function deshabilitarCamposYBoton() {
                const camposDeshabilitar = document.querySelectorAll('.campo-deshabilitar');
                camposDeshabilitar.forEach(campo => {
                    campo.disabled = true;
                });
                buttonToCreatePropuesta.disabled = true;
            }

            function ocultarBotonCalificar() {
                buttonCalificar.style.display = 'none';
            }
            buttonCalificar.addEventListener('click', function() {
                buttonEnviarCalificacion.style.display = 'inline-block';
            });
            //verificar fecha

            const deshabilitarCampos = () => {
                const camposDeshabilitar = document.querySelectorAll('.campo-deshabilitar');
                camposDeshabilitar.forEach(campo => {
                    campo.disabled = true;
                });
            }



            const ocultarCamposCalificacion = () => {
                const camposCalificacion = document.querySelectorAll('.campos-calificacion');

                camposCalificacion.forEach(campos => {
                    campos.style.display = 'none';
                    // Quitar el atributo required de los campos dentro de la sección
                    campos.querySelectorAll('input, textarea').forEach(campo => {
                        campo.required = false;
                        campo.disabled = true; // Deshabilitar campos al ocultar
                    });
                });

                // Ocultar el botón de enviar calificación
                buttonEnviarCalificacion.style.display = 'none';
            }


            // Asegurarse de que los campos de calificación no estén marcados como required inicialmente
            ocultarCamposCalificacion();

            // Auto-expandir textarea
            const textareas = document.querySelectorAll('.auto-expand');
            textareas.forEach(textarea => {
                textarea.addEventListener('input', function() {
                    this.style.height = 'auto';
                    this.style.height = (this.scrollHeight) + 'px';
                });
            });

            // Validar campos al cargar la página
            validarCampos();

            // Validar campos al cambiar el contenido de los campos
            const inputs = document.querySelectorAll('input, textarea');
            inputs.forEach(input => {
                input.addEventListener('input', validarCampos);
            });

        });
    </script>


<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\GestionProyectosGrado\resources\views/Layouts/propuesta/create.blade.php ENDPATH**/ ?>