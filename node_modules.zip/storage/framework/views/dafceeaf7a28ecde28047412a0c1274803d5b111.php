<?php echo $__env->make('notify::components.notify', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title>SEGETGRA</title>
    <link rel="shortcut icon" href="<?php echo e(asset('imgs/logos/aunar.png')); ?>" type="image/x-icon">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <!-- Scripts -->
    <script src="https://code.jquery.com/jquery-3.7.0.js" integrity="sha256-JlqSTELeR4TLqP0OG9dxM7yDPqX1ox/HfgiSLBj8+kM="
        crossorigin="anonymous"></script>
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>
    
    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>

    <!-- Bootstrap -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.min.js"></script>

    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/login.css')); ?>" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('css/slidebar.css')); ?>">
    <?php echo $__env->yieldContent('styles'); ?>
    <?php echo notifyCss(); ?>
    <?php echo $__env->yieldContent('js_head'); ?>
</head>

<body>
    <div id="app">
        <header>

            <div class="container">
                <div class="logo_content">
                    <i class='bx bx-menu' id="btn"></i>
                </div>
                <div class="logo_name">
                    <img src="<?php echo e(asset('imgs/logos/escudo.png')); ?>" alt="" width="70">
                    <div class="title">
                        SEGETGRA
                    </div>
                </div>
                <div class="name_user" style="color: #fff;">
                    <?php if(auth()->guard()->check()): ?>
                        <?php
                            $user = Auth::user();
                            $usuario = App\Models\UsuariosUser::where('usua_users', $user->id)->first();
                            $nombre = $usuario ? $usuario->nombre . " " . $usuario->apellido : 'Nombre no disponible';
                        ?>
                        <span id="nombreUsuario"><?php echo e($nombre); ?></span>

                        <a class="cerrar-sesion" href="<?php echo e(route('logout')); ?>"
                           onclick="event.preventDefault();
                                         document.getElementById('logout-form').submit();"
                           title="Cerrar sesión">
                            <img src="<?php echo e(asset('imgs/logos/cerrar.png')); ?>" alt="">
                        </a>
                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                            <?php echo csrf_field(); ?>
                        </form>
                    <?php endif; ?>
                </div>
            </div>
        </header>
        <main class="py-4">
            <?php echo $__env->yieldContent('content'); ?>
        </main>
    </div>
    <script>
        <?php echo $__env->yieldContent('script'); ?>
        $('#table-js').DataTable({
        responsive: true,
        autoWidth: false,
        "language": {
            "lengthMenu": "Mostrar _MENU_ registros por pagina",
            "zeroRecords": "Sin registros",
            "info": "Pagina _PAGE_ de _PAGES_",
            "infoEmpty": "No se encontraron resultados",
            "infoFiltered": "(filtrado de _MAX_ registros totales)",
            "search": "Buscar:",
            "paginate": {
                "next": "Siguiente",
                "previous": "Anterior"
            }
        }
    });
    </script>

    <?php echo notifyJs(); ?>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\GestionProyectosGrado\resources\views/Layouts/app.blade.php ENDPATH**/ ?>