<?php $__env->startSection('estilos_adicionales'); ?>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.3.0/css/bootstrap.min.css" rel='stylesheet'>
<link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/dataTables.bootstrap5.min.css" rel='stylesheet'>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('dashboard_content'); ?>
<br>
<h1>Sedes</h1>
    <br>
    <button type="submit" class="btn" style="background:#003E65; color:#fff; margin-bottom:30px;" onclick="actModalCrearSede()">Crear una nueva sede</button>
    <div class="modal" tabindex="-1" id="modalNuevaSede">
    <?php $__env->startComponent('components.Modales.createSede'); ?>

    <?php echo $__env->renderComponent(); ?>
</div>
    <table class="table table-hover shadow-lg mt-4" style="width:100%" id='table-js'>
        <thead>
            <tr>
                <th scope="col">Sede</th>
                <th scope="col">Telefono</th>
                <th scope="col">E-mail</th>
                <th scope="col">Direccion</th>
                <th scope="col"></th>
                <th scope="col"></th>
                <th scope="col"></th>
                <th scope="col"></th>
            </tr>
        </thead>

        <tbody>
            <?php $__currentLoopData = $sedes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sede): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($sede->sede); ?></td>
                    <td><?php echo e($sede->telefono); ?></td>
                    <td><?php echo e($sede->email); ?></td>
                    <td><?php echo e($sede->direccion); ?></td>
                    <td>
                        <form action="<?php echo e(route('facultades.index', $sede->idSede)); ?>" method="get">

                            <input type="hidden" class="form-control" name="idSede" value="<?php echo e($sede->idSede); ?>">
                            <button type="submit" class="btn " style="background:#003E65; color:#fff">Facultades</button>
                        </form>
                    </td>
                    <td>
                        <form action="<?php echo e(route('programas.index', $sede->idSede)); ?>" method="get">
                           
                            <input type="hidden" class="form-control" name="idSede" value="<?php echo e($sede->idSede); ?>">
                            <button type="submit" class="btn " style="background:#003E65; color:#fff">Programas</button>
                        </form>
                    </td>
                    <td>
                        <form action="<?php echo e(route('comite.index')); ?>">
                            <?php echo csrf_field(); ?>
                            <button type="submit" class="btn " style="background:#003E65; color:#fff">Comites</button>
                        </form>
                    </td>

                    <td>
                        <form action="<?php echo e(route('sedes.edit', $sede->idSede)); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <button type="submit" class="btn btn-warning">Editar</button>
                        </form>
                    </td>

                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php $__env->startSection('js'); ?>
<script src="https://code.jquery.com/jquery-3.7.0.js"></script>
<script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.13.6/js/dataTables.bootstrap5.min.js"></script>
<?php $__env->stopSection(); ?>
<script>
    function actModalCrearSede() { //Activa el modal para crear una nueva sede
            $('#modalNuevaSede').modal('show');
        }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\GestionProyectosGrado\resources\views/Layouts/sedes/read.blade.php ENDPATH**/ ?>