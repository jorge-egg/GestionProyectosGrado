<?php $__env->startSection('dashboard_content'); ?>

<h1>Agregar Integrante al Comité</h1>

<form method="post" action="<?php echo e(route('comite.guardar-integrante', $comite->idComite)); ?>">
    <?php echo csrf_field(); ?>

    <div class="mb-3">
        <label for="docente" class="form-label">Seleccionar Docente:</label>
        <select class="form-select" id="docente" name="docente" required>
            <option value="" selected disabled>Seleccionar docente</option>
            <?php $__currentLoopData = $docentes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $docente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($docente->numeroDocumento); ?>"><?php echo e($docente->usuario()); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>

    <button type="submit" class="btn btn-primary">Agregar Integrante</button>
</form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\GestionProyectosGrado\resources\views/Layouts/comites/agregar-integrante.blade.php ENDPATH**/ ?>