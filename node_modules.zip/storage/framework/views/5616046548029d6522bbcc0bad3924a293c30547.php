
<nav id="NavbarContainer" class="d-flex justify-content-between flex-wrap p-2 col-sm-12">
    <div id="logoTitulo">
        <div class="logo col-sm-6">
                <img src="<?php echo e(asset('imgs/logos/escudo.png')); ?>" alt="Logo">
        </div>
        <div class="titulo col-sm-6">
            <h2>SEGETGRA</h2>
        </div>
    </div>
</nav>
<?php /**PATH C:\xampp\htdocs\GestionProyectosGrado\resources\views/components/NavbarComponent.blade.php ENDPATH**/ ?>