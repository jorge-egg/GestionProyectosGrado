@extends('dashboard')

@section('estilos_adicionales')
    <link rel="stylesheet" href="{{ asset('css/coloresBtnCampos.css') }}">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.3.0/css/bootstrap.min.css"
        rel='stylesheet'>
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/dataTables.bootstrap5.min.css" rel='stylesheet'>
@endsection
@section('dashboard_content')
    <h1>usuarios</h1>
    <br>
    @if (session()->has('success'))
        <div class= 'alert alert-success'>
            {{ session()->get('success') }}
        </div>
    @endif
    <div class='col col-md-6 '>
        <a href="{{ route('usuarios.index', ['view_deleted' => 'DeletedRecords']) }}"class='btn btn-warning'>Consultar
            usuarios
            eliminados</a>
    </div>
    <br>
    <div class='col col-md-6 '>
        <a href="{{ route('usuarios.create')}}" class='btn btn-warning'>crear usuario</a>
</div>
    <table class="table table-hover shadow-lg mt-4" style="width:100%" id='table-js'>
        <thead class='bg-table'>
            <tr>
                <th scope="col">Documento</th>
                <th scope="col">Nombre</th>
                <th scope="col">Apellido</th>
                <th scope="col">Email</th>
                <th scope="col">Telefono</th>
                @can('usuario.bloquear')
                    <th scope="col"></th>
                @endcan
                @can('usuario.editar')
                    <th scope="col"></th>
                @endcan
                @can('usuario.eliminar')
                    <th scope="col"></th>
                @endcan
            </tr>
        </thead>
        <tbody>
            @foreach ($usuarios as $usuario)
                <tr>
                    <th>{{ $usuario->numeroDocumento }}</th>
                    <td>{{ $usuario->nombre }}</td>
                    <td>{{ $usuario->apellido }}</td>
                    <td>{{ $usuario->email }}</td>
                    <td>{{ $usuario->numeroCelular }}</td>
                    @can('usuario.bloquear')
                        <td>
                            <form action="{{ route('usuarios.cambioEstado', $usuario->numeroDocumento) }}" method="post">
                                @csrf

                                @if ($usuario->estado == 1)
                                    <button type="submit" class="btn btn-primary text-dark"><i
                                            class='bx
                                    bxs-user-x'></i>Deshabilitar</button>
                                @else
                                    <button type="submit" class="btn" style="background:#003E65; color:#fff"><i
                                            class="btn " style="background:#003E65; color:#fff">habilitar</i></button>
                                @endif
                            </form>
                        </td>
                    @endcan
                    @can('usuario.editar')
                        <td>

                            <form action="{{ route('usuarios.edit', $usuario->numeroDocumento) }}" method="post">
                                @csrf

                                <button type="submit" class="btn btn-warning">Editar</button>

                            </form>


                        </td>
                    @endcan
                    @can('usuario.eliminar')
                        <td>



                            @if (request()->has('view_deleted'))
                                <a href="{{ route('usuarios.restore', $usuario->numeroDocumento) }}" class="btn "
                                    style="background:#003E65; color:#fff">Restablecer</a>
                            @else
                                <form action="{{ route('usuarios.destroy', $usuario->numeroDocumento) }}" method="post">
                                    @csrf
                                    <button type="submit" class="btn btn-warning">Eliminar</button>
                                </form>
                            @endif

                        </td>
                    @endcan
            @endforeach
        </tbody>
    </table>
@section('js')
    <script src="https://code.jquery.com/jquery-3.7.0.js"></script>
    <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.6/js/dataTables.bootstrap5.min.js"></script>
@endsection
<script>
    let table = new DataTable('#usuario');
</script>
@stop
