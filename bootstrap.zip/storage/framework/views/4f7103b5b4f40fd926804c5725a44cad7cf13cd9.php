<div class="modal-dialog" role="document">
    <div class="modal-content">
        <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Docentes</h5>
            <a href="<?php echo e(url()->previous()); ?>" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </a>
        </div>
        <div class="modal-body">
            <div class="accordion" id="accordionExample">
                <?php
                    $programas = App\Models\SedePrograma::all();
                ?>

                <?php $__currentLoopData = $programas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $programa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="accordion-item">
                        <h2 class="accordion-header" id="heading<?php echo e($programa->idPrograma); ?>">
                            <button class="accordion-button" type="button" data-bs-toggle="collapse"
                                data-bs-target="#collapse<?php echo e($programa->idPrograma); ?>" aria-expanded="false"
                                aria-controls="collapse<?php echo e($programa->idPrograma); ?>">
                                <?php echo e($programa->programa); ?>

                            </button>
                        </h2>
                        <div id="collapse<?php echo e($programa->idPrograma); ?>" class="accordion-collapse collapse"
                            aria-labelledby="heading<?php echo e($programa->idPrograma); ?>" data-bs-parent="#accordionExample">
                            <div class="accordion-body">
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th scope="col">#</th>
                                            <th scope="col">Docente</th>
                                            <th scope="col">Sede</th>
                                            <th scope="col"></th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                            $contador = 0;
                                        ?>

                                        <?php $__currentLoopData = $docentes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $docente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                            <?php if($programa->idPrograma == $docente->programa): ?>
                                                <?php
                                                    $contador++;
                                                ?>
                                                <tr>
                                                    <form method="post">
                                                        <?php echo csrf_field(); ?>
                                                        <input type="hidden" value=<?php echo e($idProyecto); ?>

                                                            name="idProyecto">
                                                        <input type="hidden" value=<?php echo e($docente->numeroDocumento); ?>

                                                            name="numeroDocumento">
                                                        <th scope="row"><?php echo e($contador); ?></th>
                                                        <td><?php echo e($docente->nombre . ' ' . $docente->apellido); ?></td>
                                                        <td><?php echo e($docente->sede); ?></td>
                                                        <td>
                                                            <?php if($fase == 'propuesta'): ?>
                                                                <button formaction="<?php echo e(route('propuesta.asigDocente')); ?>"
                                                                type="submit"><i
                                                                class="bi bi-person-fill-add"></i></button>
                                                            <?php endif; ?>
                                                            <?php if($fase == 'anteproyecto'): ?>
                                                            <button formaction="<?php echo e(route('anteproyecto.asigJurado')); ?>"
                                                            type="submit"><i
                                                            class="bi bi-person-fill-add"></i></button>
                                                            <?php endif; ?>
                                                            </td>
                                                    </form>
                                                </tr>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>


        </div>
        <div class="modal-footer">
            <a href="<?php echo e(url()->previous()); ?>" class="btn btn-secondary text-dark" data-dismiss="modal">Cerrar</a>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\GestionProyectosGrado\resources\views/components/Modales/buscarDocente.blade.php ENDPATH**/ ?>