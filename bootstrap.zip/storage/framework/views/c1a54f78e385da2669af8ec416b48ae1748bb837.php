
<div class="input-group mb-3 campos-calificacion" style="display: <?php echo e($styleDisplayGeneral); ?>">
    <textarea class="form-control auto-expand" id="Observaciones" placeholder="Observaciones" name="<?php echo e($nameTextArea); ?>"
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('anteproyecto.subirDocumento','anteproyecto.aprobarDocumento')): ?>
            disabled
        <?php endif; ?>>
    </textarea>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('anteproyecto.calificar')): ?>
        <span class="input-group-text" id="basic-addon2" style="display: <?php echo e($styleDisplaySpan); ?>">
            <select class="form-select" aria-label="Default select example" name="<?php echo e($nameSelect); ?>">
                <option value="si">Si</option>
                <option value="parcial">Parcial</option>
                <option value="no" selected>No</option>
            </select>
        </span>
    <?php endif; ?>

</div>
<?php /**PATH C:\xampp\htdocs\GestionProyectosGrado\resources\views/components/calificacionObser.blade.php ENDPATH**/ ?>