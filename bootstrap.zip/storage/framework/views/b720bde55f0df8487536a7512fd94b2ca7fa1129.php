

<?php $__env->startSection('estilos_adicionales'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/coloresBtnCampos.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('dashboard_content'); ?>
    <div class="titulo">
        <h2>Cronograma</h2>
    </div>
    <div>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('cronograma.crear')): ?>
            <form action="<?php echo e(route('grupo.create')); ?>" method="get">
                <button class="btn " style="background:#003E65; color:#fff">Nuevo grupo</button>
            </form>
        <?php endif; ?>

        <table class="table">
            <thead class="encabezado">
                <tr>
                    <th scope="col"></th>
                    <th scope="col">Propuesta</th>
                    <th scope="col">Anteproyecto</th>
                    <th scope="col">Proyecto final</th>
                    <th scope="col">Sustentación</th>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('cronograma.editar')): ?>
                        <th></th>
                    <?php endif; ?>

                </tr>
            </thead>
            <tbody class="columnas">

                <?php $__currentLoopData = $array; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $grupos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="columna">
                        <td><?php echo e($key); ?></td>
                        <?php $__currentLoopData = $grupos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $grupo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $fecha_apertura = Carbon\Carbon::parse($grupo->fecha_apertura)->format('Y-m-d');
                                $fecha_cierre = Carbon\Carbon::parse($grupo->fecha_cierre)->format('Y-m-d');
                                $fechaActual = Carbon\Carbon::now()->format('Y-m-d');
                                $activo = false;
                                if ($fechaActual >= $fecha_apertura && $fechaActual <= $fecha_cierre) {
                                    $activo = true;
                                } elseif ($fechaActual > $fecha_cierre) {
                                    $activo = false;
                                }
                            ?>
                            <td class="campoFechas <?php echo e(($activo) ? 'campo-habilitado' : 'campo-deshabilitado'); ?>">
                                <p class="fechaAbierto"><?php echo e($grupo->fecha_apertura); ?></p>
                                <br>
                                <p class="fechaCerrado"><?php echo e($grupo->fecha_cierre); ?></p>
                            </td>

                            <form action="<?php echo e(route('grupo.edit', $grupo->fech_grup)); ?>" method="get">
                                <!--se coloco el inicio del from dentro de la etiqueta td para que lograra capturar el id del grupo-->
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('cronograma.editar')): ?>
                            <td>
                                <button class="btn btn-warning">editar</button>
                            </td>
                        <?php endif; ?>

                    </form>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js_extra'); ?>
    <script>
        // $('.campoFechas').each(function() {
        //     var fechaAbierto = new Date($(this).find('.fechaAbierto').text()).toLocaleDateString();
        //     var fechaCerrado = new Date($(this).find('.fechaCerrado').text()).toLocaleDateString();
        //     var fechaActual = new Date().toLocaleDateString();

        //     var fechaAbierto1 = new Date($(this).find('.fechaAbierto').text()).getDay();
        //     var fechaCerrado1 = new Date($(this).find('.fechaCerrado').text()).toLocaleDateString();
        //     var fechaActual1 = new Date().toLocaleDateString();

        //     var campoFechas = $(this);
        //     console.log({
        //         fechaAbierto,
        //         fechaCerrado,
        //         fechaActual,
        //         campoFechas
        //     });
        //     if (fechaActual >= fechaAbierto && fechaActual <= fechaCerrado) {

        //         campoFechas.addClass('campo-habilitado');
        //     } else if (fechaActual > fechaCerrado) {

        //         campoFechas.addClass('campo-deshabilitado');
        //     } else if (fechaActual < fechaAbierto) {

        //         campoFechas.addClass('');
        //     }
        // });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\GestionProyectosGrado\resources\views/Layouts/cronograma/read.blade.php ENDPATH**/ ?>