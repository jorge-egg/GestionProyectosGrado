<?php $__env->startSection('styles'); ?>

    <?php echo $__env->yieldContent('estilos_adicionales'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js_head'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="sidebar">
        <ul class="nav_list">
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('usuario.leer')): ?>
            <li>
                <a href="<?php echo e(route('usuarios.index')); ?>">
                    <i class='bx bx-group'></i>
                    <span class="links_name">Usuarios</span>
                </a>
            </li>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('sede.ver')): ?>
            <li>
                <a href="<?php echo e(route('sedes.index')); ?>">
                    <i class='bx bxs-institution'></i>
                    <span class="links_name">Sedes</span>
                </a>
            </li>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('cronograma.ver')): ?>
                <li>
                    <a href="<?php echo e(route('cronograma.index')); ?>">
                        <i class='bx bxs-user-badge'></i>
                        <span class="links_name">Cronograma</span>
                    </a>
                </li>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('proyecto.ver')): ?>
            <li>
                <a href="<?php echo e(route('proyecto.index')); ?>">
                    <i class='bx bx-book'></i>
                    <span class="links_name">Proyectos</span>
                </a>
            </li>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('comite.ver')): ?>
                <li>
                    <a href="<?php echo e(route('comite.index')); ?>">
                        <i class='bx bx-sitemap'></i>
                        <span class="links_name">Comites</span>
                    </a>
                </li>
            <?php endif; ?>

        </ul>
    </div>
    <div class="contenido">
        <?php echo $__env->yieldContent('js'); ?>
        <?php echo $__env->yieldContent('dashboard_content'); ?>
        <?php echo $__env->yieldContent('js_extra'); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    let btn = document.querySelector('#btn');
    let sidebar = document.querySelector('.sidebar');

    btn.onclick = function(){
        sidebar.classList.toggle('active');
    }
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    let btn = document.querySelector('#btn');
    let sidebar = document.querySelector('.sidebar');

    let contenedor= document.querySelector('.contenido');

    btn.onclick = function(){
        sidebar.classList.toggle('active');
        contenedor.classList.toggle('active');
    }
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\GestionProyectosGrado\resources\views/dashboard.blade.php ENDPATH**/ ?>