<?php $__env->startSection('dashboard_content'); ?>

<?php echo Form::model($user, ['route' => ['usuarios.update', $user->numeroDocumento], 'method' => 'post']); ?>


<div class="mb-3">
    <label for="numeroDocumento" class="form-label">Documento</label>
    <input type="text" class="form-control" id="numeroDocumento" name="numeroDocumento" value="<?php echo e($user->numeroDocumento); ?>">
</div>
<div class="mb-3">
    <label for="nombre" class="form-label">Nombre</label>
    <input type="text" class="form-control" id="nombre" name="nombre" value="<?php echo e($user->nombre); ?>">
</div>
<div class="mb-3">
    <label for="apellido" class="form-label">Apellido</label>
    <input type="text" class="form-control" id="apellido" name="apellido" value="<?php echo e($user->apellido); ?>">
</div>
<div class="mb-3">
    <label for="email" class="form-label">Email</label>
    <input type="text" class="form-control" id="email" name="email" value="<?php echo e($user->email); ?>">
</div>
<div class="mb-3">
    <label for="numeroCelular" class="form-label">Telefono</label>
    <input type="text" class="form-control" id="numeroCelular" name="numeroCelular" value="<?php echo e($user->numeroCelular); ?>">
</div>
<div class="d-none">
    <label for="usua_sede" class="form-label">usua_sede</label>
    <input type="text" class="form-control" id="usua_sede" name="usua_sede" value="<?php echo e($user->usua_sede); ?>" readonly>
</div>
<div class="d-none">
    <label for="usua_users" class="form-label">usua_users</label>
    <input type="text" class="form-control" id="usua_users" name="usua_users" value="<?php echo e($user->usua_users); ?>" readonly>
</div>

    <h2 class="h5">Listado de roles</h2>
    <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div>
            <label>
                <?php echo Form::checkbox('roles[]', $role->id, null, ['class' => 'mr-1']); ?>

            </label>
            <?php echo e($role -> name); ?>

        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <?php echo Form::submit('Actualizar', ['class' => 'btn btn-primary text-dark']); ?>

<?php echo Form::close(); ?>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\GestionProyectosGrado\resources\views/Layouts/usuarios/update.blade.php ENDPATH**/ ?>