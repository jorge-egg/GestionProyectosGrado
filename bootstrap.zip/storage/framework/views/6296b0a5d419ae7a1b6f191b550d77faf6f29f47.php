


    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title">Agrega un integrante a tu proyecto</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">X</button>
        </div>
        <div class="modal-body">
            <p class="card-text">
                Digita el código del estudiante (documento de identidad) para enviar la invitación.
                <br>
                No agregue puntos, comas o espacios.
            </p>
        </div>
        <div class="modal-footer">
            <div class="input-group mb-3">
                <span class="input-group-text" id="basic-addon1">Cod.</span>
                <input type="text" class="form-control" placeholder="Documento de identidad" aria-label="Username" aria-describedby="basic-addon1" id="usuario" required>
                <button type="submit" class="btn btn-primary text-dark" onclick="obtenerNombre()">Verificar</button>
            </div>
        </div>
      </div>
    </div>




<?php /**PATH C:\xampp\htdocs\GestionProyectosGrado\resources\views/components/Modales/integrantesModal.blade.php ENDPATH**/ ?>