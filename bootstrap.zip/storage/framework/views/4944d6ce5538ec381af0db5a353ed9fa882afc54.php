<?php $__env->startSection('estilos_adicionales'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/anteproyecto.css')); ?>">
    <script src="<?php echo e(asset('js/anteproyecto.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('dashboard_content'); ?>
    <?php echo e($valRolComite = false); ?>

    <?php echo e($valCalif = false); ?>

    <br>
    <div style="display: flex; flex-direction:row; justify-content: space-around;">
        <p class="fs-4">Estado: <?php echo e($array['anteproyecto']->estado); ?></p>
        <p class="fs-5">Fecha de habilitación: <?php echo e($array['rangoFecha'][0]); ?> a <?php echo e($array['rangoFecha'][1]); ?></p>
        

    </div><br>
    <div class="card" style="display: flex">
        
        <h5 class="card-title text-center">Crear anteproyecto</h5>
        <div class='card-body'>
            <p class="card-text">

                

            <div>
                <div class="mb-3">
                    <form action="<?php echo e(route('anteproyecto.store')); ?>" method="post" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" value="<?php echo e($array['idProyecto']); ?>" name='idProyecto'>
                        <input type="hidden" value="<?php echo e($array['anteproyecto']->idAnteproyecto); ?>" name='idFase'>
                        <div>
                            <?php $__currentLoopData = $array ['integrantes']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key =>$array ['integrantes']): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <h1>Integrante <?php echo e($key + 1); ?>: <?php echo e($array ['integrantes']->usuarios_user->nombre); ?>

                                    <?php echo e($array ['integrantes']->usuarios_user->apellido); ?></h1>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <br>
                        <label for="formFile" class="form-label">Documento de anteproyecto</label>

                        <?php if(!$array['rangoFecha'][2]): ?>
                            <h2 style="color: red">Por favor espere la proxima fecha habilitada para esta fase</h2>
                        <?php elseif($array['docExist'] == null): ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('anteproyecto.calificar')): ?>
                                <p style="color: red">El documento no ha sido cargado. </p>
                                <input type="hidden"><?php echo e($valRolComite = true); ?></input>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('propuesta.agregar')): ?>
                                <input class="form-control input-file <?php $__errorArgs = ['docAnteProy'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="file"
                                    id="formFile" name="docAnteProy">
                                <?php $__errorArgs = ['docAnteProy'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="alert alert-danger"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                <button type="submit" id="buttonToCreatePropuesta" class="btn"
                                    style="background:#003E65; color:#fff">Agregar</button>
                            <?php endif; ?>
                        <?php elseif($array['docExist'] != null): ?>
                            <a href="<?php echo e(route('anteproyecto.verpdf', ['nombreArchivo' => $array['docExist']])); ?>"
                                target="_blank" class="btn btn-warning"><i
                                    class="bi bi-file-earmark-pdf-fill"><?php echo e(' ' . $array['docExist']); ?></i></a>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('anteproyecto.aprobarDocumento')): ?>
                                <p style="display: none"><?php echo e($valCalif = true); ?></p>
                                <?php if($array['valDocAsig']): ?>
                                    <p><b>Nota: </b>Estimado profesor para nombrar jurados al proyecto, usted debe dar su
                                        aprobación al documento.</p>
                                    <div class="form-check form-switch">
                                        <input class="form-check-input" type="checkbox" id="flexSwitchCheckDefault"
                                            name="switchAprobDoc">
                                        <label class="form-check-label" for="flexSwitchCheckDefault">Aprobación del
                                            docente</label>
                                    </div>
                                    <div class="input-group">
                                        <span class="input-group-text">Observaciones</span>
                                        <textarea class="form-control" aria-label="With textarea" name="ObsDocent" required <?php echo e($array['anteproyecto']->observaDocent == '' ? '' : 'disabled'); ?>><?php echo e($array['anteproyecto']->observaDocent); ?></textarea>
                                      </div><br>
                                    <button class="btn" style="background:#003E65; color:#fff; margin-bottom: 10px"
                                        formaction="<?php echo e(route('anteproyecto.aprobDoc')); ?>">Enviar actualizacion de estado de
                                        aprobacion del documento</button>
                                <?php endif; ?>
                            <?php endif; ?>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <br>
    <div class="card">
        <h5 class="card-title text-center">Jurados</h5>
        <div class='card-body'>
            <div class="modal fade" tabindex="-1" id="buscarDocente" role="dialog" aria-labelledby="exampleModalLabel"
                aria-hidden="true">
                <?php $__env->startComponent('components.Modales.buscarDocente', [
                    'docentes' => $miembrosDocente['docentes'],
                    'idProyecto' => $miembrosDocente['idProyecto'],
                    'fase' => 'anteproyecto',
                ]); ?>
                <?php echo $__env->renderComponent(); ?>
            </div>
            <?php
                $habilitarButtonJ = $array['anteproyecto']->juradoUno != '-1' && $array['anteproyecto']->juradoDos != '-1' ? 'disabled' : '';
            ?>
            <button type="button" data-bs-toggle="modal" data-bs-target="#buscarDocente" class="btn"
                        style="background:#003E65; color:#fff; width: 100%;" <?php echo e($habilitarButtonJ); ?>>Seleccionar
                        jurados</button>
        </div>
    </div>
    <br>
    <div class="card" style="display: flex">
        <h5 class="card-title text-center">Calificar anteproyecto</h5>
        <div class='card-body'>
            <p class="card-text">
                <?php
                    $aprobDocent = $array['anteproyecto'] == null ? false : $array['anteproyecto']->aprobacionDocen;

                ?>

                <?php if($aprobDocent == '2'): ?>
                    <section id="cont-calf">
                        <form action="<?php echo e(route('anteproyecto.store')); ?>" method='POST'>
                            <?php echo csrf_field(); ?>
                            <h5>Titulo</h5>
                            <?php $__env->startComponent('components.calificacionObser', [
                                'nameSelect' => 'tituloCalificacion',
                                'nameTextArea' => 'tituloObservacion',
                                'obsArray' => $array['observaciones'][0],
                                'styleDisplaySpan' => $valRolComite ? 'flex' : 'none',
                                'styleDisplayGeneral' => $valCalif ? 'flex' : 'none',
                            ]); ?>
                            <?php echo $__env->renderComponent(); ?>
                            <h5>Introducción</h5>
                            <?php $__env->startComponent('components.calificacionObser', [
                                'nameSelect' => 'introCalificacion',
                                'nameTextArea' => 'introObservacion',
                                'obsArray' => $array['observaciones'][1],
                                'styleDisplaySpan' => $valRolComite ? 'flex' : 'none',
                                'styleDisplayGeneral' => 'flex',
                            ]); ?>
                            <?php echo $__env->renderComponent(); ?>
                            <h5>Planteamiento del problema</h5>
                            <?php $__env->startComponent('components.calificacionObser', [
                                'nameSelect' => 'planProbCalificacion',
                                'nameTextArea' => 'planProbObservacion',
                                'obsArray' => $array['observaciones'][2],
                                'styleDisplaySpan' => $valRolComite ? 'flex' : 'none',
                                'styleDisplayGeneral' => 'flex',
                            ]); ?>
                            <?php echo $__env->renderComponent(); ?>
                            <h5>Justificación</h5>
                            <?php $__env->startComponent('components.calificacionObser', [
                                'nameSelect' => 'justCalificacion',
                                'nameTextArea' => 'justObservacion',
                                'obsArray' => $array['observaciones'][3],
                                'styleDisplaySpan' => $valRolComite ? 'flex' : 'none',
                                'styleDisplayGeneral' => 'flex',
                            ]); ?>
                            <?php echo $__env->renderComponent(); ?>
                            <h5>Marco referencial</h5>
                            <?php $__env->startComponent('components.calificacionObser', [
                                'nameSelect' => 'marcRefCalificacion',
                                'nameTextArea' => 'marcRefObservacion',
                                'obsArray' => $array['observaciones'][4],
                                'styleDisplaySpan' => $valRolComite ? 'flex' : 'none',
                                'styleDisplayGeneral' => 'flex',
                            ]); ?>
                            <?php echo $__env->renderComponent(); ?>
                            <h5>Metodologia</h5>
                            <?php $__env->startComponent('components.calificacionObser', [
                                'nameSelect' => 'metodCalificacion',
                                'nameTextArea' => 'metodObservacion',
                                'obsArray' => $array['observaciones'][5],
                                'styleDisplaySpan' => $valRolComite ? 'flex' : 'none',
                                'styleDisplayGeneral' => 'flex',
                            ]); ?>
                            <?php echo $__env->renderComponent(); ?>
                            <h5>Elementos de administración y control</h5>
                            <?php $__env->startComponent('components.calificacionObser', [
                                'nameSelect' => 'admCtrCalificacion',
                                'nameTextArea' => 'admCtrObservacion',
                                'obsArray' => $array['observaciones'][6],
                                'styleDisplaySpan' => $valRolComite ? 'flex' : 'none',
                                'styleDisplayGeneral' => 'flex',
                            ]); ?>
                            <?php echo $__env->renderComponent(); ?>
                            <h5>Normas de presentación en el documento y Referencias bibliográficas</h5>
                            <?php $__env->startComponent('components.calificacionObser', [
                                'nameSelect' => 'normBibliCalificacion',
                                'nameTextArea' => 'normBibliObservacion',
                                'obsArray' => $array['observaciones'][7],
                                'styleDisplaySpan' => $valRolComite ? 'flex' : 'none',
                                'styleDisplayGeneral' => 'flex',
                            ]); ?>
                            <?php echo $__env->renderComponent(); ?>
                            <br>
                            <div class="mb-3">
                                <button id="buttonEnviarCalificacion"
                                    formaction="<?php echo e(route('observaciones.store', 'anteproyecto')); ?>" class="btn"
                                    style="background:#003E65; color:#fff">Enviar
                                    calificación</button>

            </p>
        </div>
        </form>
        </section>
    <?php else: ?>
        <p style="color: red;">
            <?php echo e($array['anteproyecto']->aprobacionDocen == '1'
                ? 'El director no aprobo el documento'
                : ($array['anteproyecto']->aprobacionDocen == '-1'
                    ? 'No se podra calificar el anteproyecto hasta que el director apruebe el
                                                documento'
                    : '')); ?>

        </p>
        <?php endif; ?>

        <?php endif; ?>
        </form>
    </div>


    </div>


<?php $__env->startSection('js'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\GestionProyectosGrado\resources\views/Layouts/anteproyecto/create.blade.php ENDPATH**/ ?>