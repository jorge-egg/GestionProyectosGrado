<?php $__env->startSection('dashboard_content'); ?>
    <h1>Crear Usuario</h1>

    <?php if(Session::has('success')): ?>
        <div class="alert alert-success">
            <?php echo e(Session::get('success')); ?>

        </div>
    <?php endif; ?>

    <form action="<?php echo e(route('usuarios.store')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <div class="mb-3">
            <label for="numeroDocumento" class="form-label">Número de Documento:</label>
            <input type="text" name="numeroDocumento" class="form-control" required>
        </div>

        <!-- Agregar campo para la contraseña -->
        <div class="mb-3">
            <label for="password" class="form-label">Contraseña:</label>
            <input type="password" name="password" class="form-control" required>
        </div>

        <!-- Agregar campo para confirmar la contraseña -->
        <div class="mb-3">
            <label for="password_confirmation" class="form-label">Confirmar Contraseña:</label>
            <input type="password" name="password_confirmation" class="form-control" required>
        </div>
        <!-- Mensajes de error para la validación de la contraseña -->
        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="alert alert-danger"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        <!-- Mensajes de error para la validación de la confirmación de contraseña -->
        <?php $__errorArgs = ['password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="alert alert-danger"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        <div class="mb-3">
            <label for="nombre" class="form-label">Nombres:</label>
            <input type="text" name="nombre" class="form-control" required>
        </div>

        <div class="mb-3">
            <label for="apellido" class="form-label">Apellidos:</label>
            <input type="text" name="apellido" class="form-control" required>
        </div>


        <div class="mb-3">
            <label for="email" class="form-label">Email:</label>
            <input type="email" name="email" class="form-control" required>
        </div>

        <div class="mb-3">
            <label for="numeroCelular" class="form-label">Número de Celular:</label>
            <input type="text" name="numeroCelular" class="form-control" required>
        </div>

        <div class="mb-3">
            <label for="usua_sede" class="form-label">Sede:</label>
            <select name="usua_sede" class="form-select" required onchange="getProgramasBySede(this.value)">
                <option value="" selected disabled>Seleccionar Sede</option>
                <?php $__currentLoopData = $sedes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sede): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($sede->idSede); ?>"><?php echo e($sede->sede); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        

        <div class="mb-3">
            <label for="programa" class="form-label">Programa:</label>
            <select name="programa" class="form-select" id="programaSelect">
                <option value="" selected>Seleccionar Programa</option> <!-- Opción por defecto -->
                <!-- Las opciones se completarán dinámicamente según la sede seleccionada. -->
            </select>
        </div>


        <button type="submit" class="btn " style="background:#003E65; color:#fff">Crear Usuario</button>
    </form>

    <script>
        // function handleRoleChange() {
        //     const rolesCheckbox = document.getElementsByName('roles[]');
        //     const programaSelect = document.getElementById('programaSelect');

        //     // Verificar si el rol de estudiante está seleccionado
        //     const isEstudiante = Array.from(rolesCheckbox).some(checkbox => checkbox.value === 'estudiante' && checkbox
        //         .checked);

        //     // Habilitar/deshabilitar y establecer/eliminar 'required' en el campo de programa
        //     programaSelect.disabled = !isEstudiante;
        //     programaSelect.required = isEstudiante;
        // }

        function getProgramasBySede(sedeId) {
            // Hacer una solicitud AJAX para obtener los programas de la sede seleccionada
            // y actualizar dinámicamente el contenido del select de programas
            fetch("<?php echo e(url('get-programas-by-sede')); ?>/" + sedeId)
                .then(response => response.json())
                .then(data => {
                    const programaSelect = document.getElementById('programaSelect');
                    programaSelect.innerHTML = ""; // Limpiar las opciones actuales

                    // Agregar la opción por defecto
                    const defaultOption = document.createElement('option');
                    defaultOption.value = "";
                    defaultOption.text = "Seleccionar Programa";
                    programaSelect.add(defaultOption);

                    // Agregar las opciones dinámicamente
                    data.forEach(programa => {
                        const option = document.createElement('option');
                        option.value = programa.idPrograma;
                        option.text = programa.programa;
                        programaSelect.add(option);
                    });
                });
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\GestionProyectosGrado\resources\views/Layouts/usuarios/create.blade.php ENDPATH**/ ?>